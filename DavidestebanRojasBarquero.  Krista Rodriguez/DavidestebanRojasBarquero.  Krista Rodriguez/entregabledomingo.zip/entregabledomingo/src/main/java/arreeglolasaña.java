
public class arreeglolasaña  {
 protected int nlasañas;
 protected int saborlasaña;
 protected int preciolasaña;
 protected int montolasaña;

public void arreglopizza(){
this.montolasaña=0;
this.nlasañas=0;
this.preciolasaña=0;
this.preciolasaña=0;
}


    public int getNlasañas() {
        return nlasañas;
    }

    public void setNlasañas(int nlasañas) {
        this.nlasañas = nlasañas;
    }

    public int getSaborlasaña() {
        return saborlasaña;
    }

    public void setSaborlasaña(int saborlasaña) {
        this.saborlasaña = saborlasaña;
    }

    public int getPreciolasaña() {
        return preciolasaña;
    }

    public void setPreciolasaña(int preciolasaña) {
        this.preciolasaña = preciolasaña;
    }

    public int getMontolasaña() {
        return montolasaña;
    }

    public void setMontolasaña(int montolasaña) {
        this.montolasaña = montolasaña;
    }
}
    











