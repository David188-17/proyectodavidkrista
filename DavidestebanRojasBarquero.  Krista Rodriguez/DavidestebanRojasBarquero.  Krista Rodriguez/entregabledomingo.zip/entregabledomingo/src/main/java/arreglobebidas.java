
public class arreglobebidas {
     protected int nbebidas;
 protected int bebidatamaño;
 protected int preciobebida;
 protected int montobebida;

public void arreglopizza(){
this.montobebida=0;
this.nbebidas=0;
this.preciobebida=0;
this.preciobebida=0;








}

    public int getNbebidas() {
        return nbebidas;
    }

    public void setNbebidas(int nbebidas) {
        this.nbebidas = nbebidas;
    }

    public int getBebidatamaño() {
        return bebidatamaño;
    }

    public void setBebidatamaño(int bebidatamaño) {
        this.bebidatamaño = bebidatamaño;
    }

    public int getPreciobebida() {
        return preciobebida;
    }

    public void setPreciobebida(int preciobebida) {
        this.preciobebida = preciobebida;
    }

    public int getMontobebida() {
        return montobebida;
    }

    public void setMontobebida(int montobebida) {
        this.montobebida = montobebida;
    }

}