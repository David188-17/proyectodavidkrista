
public class arreglopizza {
    protected int npizzas;
 protected int pizzatamaño;
 protected int precio;
 protected int montopizza;

public void arreglopizza(){
this.montopizza=0;
this.npizzas=0;
this.precio=0;
this.pizzatamaño=0;
























}

    public int getNpizzas() {
        return npizzas;
    }

    public void setNpizzas(int npizzas) {
        this.npizzas = npizzas;
    }

    public int getPizzatamaño() {
        return pizzatamaño;
    }

    public void setPizzatamaño(int pizzatamaño) {
        this.pizzatamaño = pizzatamaño;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getMontopizza() {
        return montopizza;
    }

    public void setMontopizza(int montopizza) {
        this.montopizza = montopizza;
    }
}